# --- Hack.Diversity React/Redux Template ---

## Getting Started
Wondering how to get this thing working? Well, do we have the READMEs for you!
- [server](server/README.md)
- [client](client/README.md)

## Deployment
-  [Amplify](/docs/amplify/README.md)
-  [Beanstalk](/docs/beanstalk/README.md)
