import DeleteButton from './DeleteButton';

export {
    DeleteButton,
};
