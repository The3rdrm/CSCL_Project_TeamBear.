/* eslint-disable semi */
import React from 'react';

const Welcome = () =>
    <div className="welcome--container">
        <h3 className="welcome--message-text">Welcome to TBD :)</h3>
        <p className="welcome--description-text">Also TBD!</p>
    </div>

export default Welcome;
