import { combineReducers } from 'redux';
import itemData from './itemReducer';

export const rootReducer = combineReducers({
    itemData
});
